/**
 * Levanta todo para jugar en esta compu: los juegos (Vite) y el servidor online, y abre el navegador.
 *
 *   npm run jugar        (en Windows también: doble clic en jugar.bat)
 *
 * La primera vez instala lo que haga falta. Para cerrar: Ctrl+C en esta ventana.
 * Desde otra compu o un celular de la misma red se entra con la dirección que aparece abajo.
 */
import { spawn, spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { networkInterfaces } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const win = process.platform === 'win32';

for (const dir of ['.', 'server']) {
  if (existsSync(join(root, dir, 'node_modules'))) continue;
  console.log(`\nInstalando lo necesario en ${dir === '.' ? 'los juegos' : 'el servidor'} (solo la primera vez)…\n`);
  const r = spawnSync(win ? 'npm.cmd' : 'npm', ['install'], { cwd: join(root, dir), stdio: 'inherit', shell: win });
  if (r.status !== 0) process.exit(r.status || 1);
}

const ips = Object.values(networkInterfaces())
  .flat()
  .filter((a) => a && a.family === 'IPv4' && !a.internal)
  .map((a) => a.address);
console.log('\n  Juegos:          http://localhost:5173');
for (const ip of ips) console.log(`  En la misma red: http://${ip}:5173`);
console.log('  Servidor online: puerto 8787 (si Windows pregunta por el firewall, dejá pasar a Node)');
console.log('  Para cerrar: Ctrl+C\n');

const kids = [
  spawn(process.execPath, [join(root, 'server', 'index.js')], { cwd: root, stdio: 'inherit' }),
  spawn(process.execPath, [join(root, 'node_modules', 'vite', 'bin', 'vite.js'), '--host', '--open'], { cwd: root, stdio: 'inherit' }),
];
const stop = () => {
  for (const k of kids) k.kill();
  process.exit(0);
};
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
for (const k of kids) k.on('exit', (code) => code && stop());
