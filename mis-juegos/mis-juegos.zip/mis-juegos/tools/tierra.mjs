#!/usr/bin/env node
/**
 * Pasa los colores de los juegos a la paleta tierra de esta copia: colores lisos y apagados, sin flúor
 * y sin brillos.
 *
 *   npm run tierra                 → los juegos que todavía no se pasaron (por ejemplo, uno nuevo que
 *                                    trajiste del repo original)
 *   npm run tierra -- drift naval  → solo esos (aunque ya se hayan pasado: ojo, cada pasada apaga un
 *                                    poco más)
 *   npm run tierra -- --ver drift  → no cambia nada: muestra qué colores cambiaría y cómo quedan
 *   npm run tierra -- --solo-brillos drift → solo saca los brillos, sin tocar los colores
 *
 * Qué hace con cada juego (public/games/<id>/ y server/games/<id>.js):
 *   - Cada color escrito en el código (#hex, rgb(), rgba(), hsl(), hsla(), 0xRRGGBB de three.js y los
 *     nombres de color en CSS y SVG) pasa por tierra(): menos saturación, tonos llevados hacia la paleta
 *     (terracota, mostaza, oliva, verde azulado, petróleo, ciruela y rosa viejo), grises cálidos y los
 *     negros y blancos puros un poco más suaves, como el portal.
 *   - Saca los brillos del CSS y de los SVG: sombras sin desplazamiento con desenfoque (text-shadow,
 *     box-shadow, drop-shadow) y filtros de desenfoque usados como resplandor.
 * Lo que el juego calcula mientras corre (por ejemplo `hsl(${tono}, 100%, 60%)`) no se puede cambiar
 * desde acá: la herramienta lo avisa para revisarlo a mano.
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { tierraRgb, rgbToOklch, mapToken, NOMBRES, parseHex, clamp } from '../public/shared/tierra.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const GAMES = path.join(ROOT, 'public/games');
const HECHOS = path.join(ROOT, 'tools/tierra.json');

/** Luz y saturación (ya en tierra) de un color escrito; null si no es un color. */
function lch(tok) {
  const out = mapToken(tok);
  if (!out) return null;
  let rgb;
  if (out.startsWith('#')) rgb = parseHex(out.slice(0, 7)).rgb;
  else if (out.startsWith('0x')) rgb = parseHex(out.slice(2)).rgb;
  else rgb = out.match(/[\d.]+/g).slice(0, 3).map(Number);
  return rgbToOklch(rgb);
}

// ---------------------------------------------------------------- reemplazos en el texto

const HEX = /#(?:[0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{3,4})(?![0-9a-zA-Z_-])/g;
const FUNC = /\b(?:rgba?|hsla?)\(\s*[\d.]+(?:deg)?%?\s*[, ]\s*[\d.]+%?\s*[, ]\s*[\d.]+%?\s*(?:[,/]\s*[\d.]+%?\s*)?\)/gi;
// un nombre de color suelto: no pegado a guiones, puntos ni comillas (pink-pulse, .red, 'Gold Sans' no son colores)
const NOMBRE = new RegExp(`(?<![\\w.'"-])(${Object.keys(NOMBRES).join('|')})(?![\\w'"-])`, 'gi');
/** Propiedades de CSS donde un nombre suelto no es un color. */
const SIN_NOMBRES = /^(font|animation|transition|grid|content|will-change|counter|list-style|quotes|font-family|src)/i;

/** Palabras de 3-4 letras que parecen #hex pero suelen ser ids (#add, #fade…): no se tocan. */
const PALABRAS = new Set(['add', 'bad', 'bed', 'cab', 'dad', 'fab', 'fad', 'fed', 'ace', 'bee', 'dab', 'deb', 'ebb', 'fee', 'cafe', 'face', 'fade', 'dead', 'beef', 'deaf', 'babe', 'bead', 'aced', 'deed', 'feed', 'abba']);

const nota = { cambios: 0, avisos: [] };

let soloBrillos = false; // npm run tierra -- --solo-brillos: saca brillos sin tocar colores

function swapColors(text, { nombres = false } = {}) {
  if (soloBrillos) return text;
  let out = text.replace(FUNC, (m) => {
    const r = mapToken(m);
    if (r && r !== m) nota.cambios++;
    return r || m;
  });
  out = out.replace(HEX, (m, off, all) => {
    if (PALABRAS.has(m.slice(1).toLowerCase())) return m;
    if (/[&\w]/.test(all[off - 1] || '')) return m; // &#123; y cosas pegadas a una palabra
    const r = mapToken(m);
    if (r && r !== m) nota.cambios++;
    return r || m;
  });
  // íconos SVG metidos en el CSS como data:…, con el # escrito %23
  out = out.replace(/%23([0-9a-fA-F]{6}|[0-9a-fA-F]{3})(?![0-9a-zA-Z])/g, (m, h) => {
    nota.cambios++;
    return '%23' + mapToken('#' + h).slice(1);
  });
  if (nombres)
    out = out.replace(NOMBRE, (m) => {
      const r = mapToken(m);
      if (r) nota.cambios++;
      return r || m;
    });
  return out;
}

// --- sombras: se sacan las que brillan (sin desplazamiento y con desenfoque, o de color claro/vivo)

function splitTop(s, sep = ',') {
  const parts = [];
  let depth = 0, cur = '';
  for (const ch of s) {
    if (ch === '(') depth++;
    if (ch === ')') depth--;
    if (ch === sep && depth === 0) {
      parts.push(cur);
      cur = '';
    } else cur += ch;
  }
  parts.push(cur);
  return parts;
}

const LEN = /^-?(?:\d+\.?\d*|\.\d+)(?:px|em|rem|vw|vh|vmin|vmax|%)?$/;

function esBrillo(shadow) {
  const tokens = splitTop(shadow.trim(), ' ').filter((t) => t && t !== 'inset');
  const inset = /(^|\s)inset(\s|$)/.test(shadow);
  // un var() al principio o al final es el color (0 0 16px var(--rosa)); en el medio, una medida
  const extremo = (i) => i === 0 || i === tokens.length - 1;
  const lens = tokens.filter((t, i) => LEN.test(t) || /^calc\(/.test(t) || (/^var\(/.test(t) && !extremo(i)));
  const color = tokens.filter((t) => !lens.includes(t)).join(' ');
  if (lens.some((t) => /^(calc|var)\(/.test(t))) return false; // no sabemos: se deja
  const n = lens.map((t) => parseFloat(t));
  const [x = 0, y = 0, blur = 0] = n;
  if (blur <= 0) return false; // bordes y sombras duras: diseño liso, se quedan
  const c = color ? lch(resolverVar(color)) : null;
  const vivo = c && (c.L > 0.55 || c.C > 0.05);
  const oscuro = c && c.L < 0.42 && c.C < 0.05;
  if (oscuro) return false; // sombra de profundidad, no brillo
  if (x === 0 && y === 0) return !inset || vivo || !c; // resplandor (o resplandor interno de color)
  return !!vivo; // sombra de color con desenfoque: se ve como brillo
}

/** Colores definidos como variables en el CSS del juego (--rosa: #f0a), para saber de qué color es una sombra. */
const variables = new Map();
function leerVariables(css) {
  for (const m of css.matchAll(/(--[\w-]+)\s*:\s*([^;{}]+?)\s*(?=[;}])/g)) if (!variables.has(m[1])) variables.set(m[1], m[2].trim());
}
function resolverVar(token, depth = 0) {
  const m = /^var\(\s*(--[\w-]+)\s*(?:,\s*(.+))?\)$/.exec(token.trim());
  if (!m || depth > 4) return token;
  const v = variables.get(m[1]) ?? m[2];
  return v ? resolverVar(v, depth + 1) : token;
}

function limpiarSombras(value) {
  const list = splitTop(value);
  const keep = list.filter((s) => !esBrillo(s));
  if (keep.length === list.length) return value;
  nota.cambios++;
  return keep.length ? keep.map((s) => s.trim()).join(', ') : 'none';
}

function limpiarFiltro(value) {
  const out = value.replace(/drop-shadow\(((?:[^()]|\([^()]*\))*)\)/g, (m, inner) => (esBrillo(inner) ? '' : m)).replace(/\s+/g, ' ').trim();
  if (out === value.trim()) return value;
  nota.cambios++;
  return out || 'none';
}

/** CSS: colores en los valores de cada declaración (no en los selectores) y sin brillos. */
function procesarCss(css) {
  return css.replace(/([{;\s])(--[\w-]+|[a-z-]+)(\s*:\s*)([^;{}]+?)(\s*)(?=[;}])/gi, (all, pre, prop, colon, value, sp) => {
    let v = value;
    const p = prop.toLowerCase();
    // primero los brillos (se deciden con el color original) y después los colores
    if (p === 'box-shadow' || p === 'text-shadow') v = limpiarSombras(v);
    if (p === 'filter' || p === '-webkit-filter') v = limpiarFiltro(v);
    v = swapColors(v, { nombres: !SIN_NOMBRES.test(prop) });
    return pre + prop + colon + v + sp;
  });
}

const ATTR_COLOR = /^(fill|stroke|stop-color|flood-color|lighting-color|color|bgcolor)$/i;

/** Los atributos de un pedazo de HTML o SVG (sin <script> ni <style>): cada uno se cambia una sola vez. */
function atributos(seg) {
  return seg.replace(/(\s)([\w:.-]+)=(?:"([^"]*)"|'([^']*)')/g, (m, sp, name, v1, v2) => {
    const q = v1 !== undefined ? '"' : "'";
    const val = v1 !== undefined ? v1 : v2;
    let out = val;
    if (ATTR_COLOR.test(name)) out = swapColors(val, { nombres: true });
    else if (/^style$/i.test(name)) out = procesarCss(';' + val + ';').slice(1, -1);
    else if (/^\s*(#[0-9a-fA-F]{3,8}|(?:rgba?|hsla?)\([^)]*\))\s*$/.test(val)) {
      const r = mapToken(val);
      if (r && r !== val.trim()) {
        nota.cambios++;
        out = r;
      }
    }
    return `${sp}${name}=${q}${out}${q}`;
  });
}

/** SVG/HTML: <script> como JS, <style> como CSS y el resto, atributos; los filtros de resplandor se apagan. */
function procesarMarcado(text) {
  const re = /(<script\b[^>]*>)([\s\S]*?)(<\/script>)|(<style\b[^>]*>)([\s\S]*?)(<\/style>)/gi;
  let out = '';
  let last = 0;
  let m;
  while ((m = re.exec(text))) {
    out += atributos(text.slice(last, m.index));
    if (m[1]) out += atributos(m[1]) + (/\bsrc=/.test(m[1]) || /json/.test(m[1]) ? m[2] : procesarJs(m[2])) + m[3];
    else out += atributos(m[4]) + procesarCss(m[5]) + m[6];
    last = re.lastIndex;
  }
  out += atributos(text.slice(last));
  // filtros de SVG que hacen resplandor (feGaussianBlur fusionado con el original): se dejan sin efecto
  out = out.replace(/\sfilter=(["'])url\(#([\w-]+)\)\1/g, (m, q, id) => {
    const def = new RegExp(`<filter[^>]*id=["']${id}["'][\\s\\S]*?</filter>`).exec(out);
    if (def && /feGaussianBlur/.test(def[0]) && !/feOffset/.test(def[0])) {
      nota.cambios++;
      return '';
    }
    return m;
  });
  return out;
}

/** JS: colores dentro de strings (incluye plantillas con CSS) y 0xRRGGBB de three.js. */
/**
 * Recorre el JS y le pasa a fn cada string y cada parte de texto de las plantillas `...`; los ${} de
 * adentro se recorren igual. Se saltean comentarios y expresiones regulares.
 */
function cadaString(js, fn) {
  let out = '';
  let i = 0;
  const n = js.length;
  let prev = ''; // último carácter significativo, para distinguir / de división y de regex
  const regexAntes = (p) => p === '' || /[(,=:[!&|?{};+\-*%<>~^]/.test(p);
  function plantilla() {
    // estamos justo después de la ` de apertura
    let texto = '';
    let res = '`';
    while (i < n) {
      const c = js[i];
      if (c === '\\') {
        texto += c + js[i + 1];
        i += 2;
        continue;
      }
      if (c === '`') {
        i++;
        return res + fn(texto, '`') + '`';
      }
      if (c === '$' && js[i + 1] === '{') {
        res += fn(texto, '`') + '${';
        texto = '';
        i += 2;
        let depth = 1;
        let code = '';
        while (i < n && depth > 0) {
          const d = js[i];
          if (d === '{') depth++;
          if (d === '}') depth--;
          if (depth === 0) break;
          if (d === '`' || d === "'" || d === '"') {
            // string dentro del ${}: se copia entero para no confundir las llaves
            const q = d;
            let j = i + 1;
            if (q === '`') {
              let dd = 0;
              while (j < n && !(js[j] === '`' && dd === 0)) {
                if (js[j] === '\\') j++;
                else if (js[j] === '$' && js[j + 1] === '{') dd++;
                else if (js[j] === '}' && dd > 0) dd--;
                j++;
              }
            } else while (j < n && js[j] !== q) j += js[j] === '\\' ? 2 : 1;
            code += js.slice(i, j + 1);
            i = j + 1;
            continue;
          }
          code += d;
          i++;
        }
        res += cadaString(code, fn) + '}';
        i++;
        continue;
      }
      texto += c;
      i++;
    }
    return res + fn(texto, '`');
  }
  while (i < n) {
    const c = js[i];
    if (c === '/' && js[i + 1] === '/') {
      const j = js.indexOf('\n', i);
      const end = j < 0 ? n : j;
      out += js.slice(i, end);
      i = end;
      continue;
    }
    if (c === '/' && js[i + 1] === '*') {
      const j = js.indexOf('*/', i + 2);
      const end = j < 0 ? n : j + 2;
      out += js.slice(i, end);
      i = end;
      continue;
    }
    if (c === '/' && regexAntes(prev)) {
      let j = i + 1;
      let clase = false;
      while (j < n && js[j] !== '\n') {
        if (js[j] === '\\') j++;
        else if (js[j] === '[') clase = true;
        else if (js[j] === ']') clase = false;
        else if (js[j] === '/' && !clase) break;
        j++;
      }
      out += js.slice(i, j + 1);
      i = j + 1;
      prev = 'x';
      continue;
    }
    if (c === "'" || c === '"') {
      let j = i + 1;
      while (j < n && js[j] !== c && js[j] !== '\n') j += js[j] === '\\' ? 2 : 1;
      out += c + fn(js.slice(i + 1, j), c) + c;
      i = j + 1;
      prev = 'x';
      continue;
    }
    if (c === '`') {
      i++;
      out += plantilla();
      prev = 'x';
      continue;
    }
    out += c;
    if (!/\s/.test(c)) prev = /[\w$)\]]/.test(c) ? 'x' : c;
    i++;
  }
  return out;
}

/** JS: colores dentro de strings (incluye plantillas con CSS o HTML) y 0xRRGGBB de three.js. */
function procesarJs(js) {
  let out = cadaString(js, (body, q) => (q === '`' ? procesarCssEnTexto(body) : swapColors(body)));
  // ctx.fillStyle = 'white' (solo asignaciones del canvas: en un objeto, color: 'red' suele ser una clave)
  out = out.replace(/((?:fillStyle|strokeStyle|shadowColor)\s*=\s*)(['"])([a-z]+)\2/gi, (m, a, q, name) => {
    const r = NOMBRES[name.toLowerCase()] ? mapToken(name) : null;
    if (!r) return m;
    nota.cambios++;
    return `${a}${q}${r}${q}`;
  });
  // 0xRRGGBB: colores de three.js; solo en archivos que usan three.js y nunca al lado de operaciones de bits
  if (/\bTHREE\b/.test(js) && !soloBrillos)
    out = out.replace(/\b0x[0-9a-fA-F]{6}\b/g, (m, off, all) => {
      const antes = all.slice(Math.max(0, off - 3), off), despues = all.slice(off + m.length, off + m.length + 3);
      if (/[&|^]\s*$|<<\s*$|>>\s*$/.test(antes) || /^\s*[&|^]|^\s*<<|^\s*>>/.test(despues)) return m;
      const r = mapToken(m);
      if (r !== m) nota.cambios++;
      return r;
    });
  // rgba(255,190,90,${alfa}): el color está escrito y solo la transparencia se calcula
  if (!soloBrillos) out = out.replace(/\b(rgba?)\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(?=\$\{|['"]\s*\+)/g, (m, fn, r, g, b) => {
    const rgb = tierraRgb([r, g, b].map((v) => clamp(+v, 0, 255)));
    nota.cambios++;
    return `${fn}(${rgb.join(',')},`;
  });
  for (const m of out.matchAll(/(?:rgba?|hsla?)\(\s*(?:\$\{|['"]\s*\+)[^)]*\)?|(?:rgba?|hsla?)\(\s*\d{1,3}\s*,\s*\$\{[^)]*\)|hsla?\([^)]*\$\{[^)]*\)/g)) nota.avisos.push(`color calculado: ${m[0].slice(0, 70)}`);
  for (const m of out.matchAll(/shadowBlur\s*=\s*(?!0\b)[^;\n]+/g)) nota.avisos.push(`brillo en canvas: ${m[0].slice(0, 70)}`);
  for (const m of out.matchAll(/globalCompositeOperation\s*=\s*['"](lighter|screen|plus-lighter|color-dodge)['"]/g)) nota.avisos.push(`mezcla que ilumina: ${m[0]}`);
  return out;
}

/** Texto de una plantilla de JS: puede tener CSS (`color: #f0f; box-shadow: …`) o HTML con style="". */
function procesarCssEnTexto(body) {
  const sinBrillos = body.replace(/((?:box|text)-shadow|(?:-webkit-)?filter)(\s*:\s*)([^;"'`{}<>]+)/gi, (m, prop, colon, value) => {
    if (/\$\{/.test(value)) return m;
    const v = /shadow/i.test(prop) ? limpiarSombras(value.trim()) : limpiarFiltro(value.trim());
    return v === value.trim() ? m : prop + colon + v;
  });
  return swapColors(sinBrillos);
}

// ---------------------------------------------------------------- archivos

function archivosDe(id) {
  const out = [];
  const walk = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p);
      else if (/\.(m?js|css|html|svg)$/.test(e.name) && !/\.min\.js$/.test(e.name)) out.push(p);
    }
  };
  walk(path.join(GAMES, id));
  const srv = path.join(ROOT, 'server/games', `${id}.js`);
  if (fs.existsSync(srv)) out.push(srv);
  return out;
}

function procesar(file, text) {
  variables.clear();
  leerVariables(text);
  if (file.endsWith('.css')) return procesarCss(text);
  if (file.endsWith('.svg') || file.endsWith('.html')) return procesarMarcado(text);
  return procesarJs(text);
}

function leerHechos() {
  try {
    return JSON.parse(fs.readFileSync(HECHOS, 'utf8'));
  } catch {
    return { hechos: [] };
  }
}

function main() {
  const args = process.argv.slice(2);
  const ver = args.includes('--ver');
  soloBrillos = args.includes('--solo-brillos');
  const pedidos = args.filter((a) => !a.startsWith('--'));
  const todos = fs.readdirSync(GAMES).filter((g) => fs.existsSync(path.join(GAMES, g, 'game.json')));
  const estado = leerHechos();
  const ids = pedidos.length ? pedidos : todos.filter((g) => !estado.hechos.includes(g));
  for (const id of ids) if (!todos.includes(id)) throw new Error(`No existe el juego "${id}" en public/games/`);
  if (!ids.length) {
    console.log('Todos los juegos ya están en la paleta tierra.');
    return;
  }
  for (const id of ids) {
    let total = 0;
    const avisos = [];
    for (const file of archivosDe(id)) {
      nota.cambios = 0;
      nota.avisos = [];
      const text = fs.readFileSync(file, 'utf8');
      const out = procesar(file, text);
      total += nota.cambios;
      avisos.push(...nota.avisos.map((a) => `  ${path.relative(ROOT, file)}: ${a}`));
      if (!ver && out !== text) fs.writeFileSync(file, out);
    }
    console.log(`${id}: ${total} cambios${ver ? ' (sin escribir)' : ''}`);
    if (avisos.length) console.log([...new Set(avisos)].join('\n'));
    if (!ver && !estado.hechos.includes(id)) estado.hechos.push(id);
  }
  if (!ver) {
    estado.hechos.sort();
    fs.writeFileSync(HECHOS, JSON.stringify(estado, null, 2) + '\n');
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();

export { mapToken, procesarCss, procesarJs, procesarMarcado };
