# Mis juegos

Copia personal de [game.it](https://github.com/emitejadaa/game.it), el portal de juegos web de
[emitejadaa](https://github.com/emitejadaa), con todos sus juegos (Voleyball incluido) y **colores lisos en tono tierra**,
sin flúor ni brillos. Es para jugar en casa: no tiene anuncios y el online usa un servidor propio que corre en la misma
compu. La historia de commits es la del original, con su autoría.

## Jugar

1. Instalá [Node.js](https://nodejs.org) 20 o más nuevo (una sola vez).
2. **Windows:** doble clic en `jugar.bat`. **Mac o Linux:** `./jugar.sh`. O en una terminal, en esta carpeta:
   `npm run jugar`.
3. La primera vez instala lo que necesita (un par de minutos). Después abre el navegador en http://localhost:5173.

Para cerrar: Ctrl+C en la ventana que quedó abierta (o cerrarla).

**Con otros en la misma red (el Wi-Fi de la casa):** la ventana muestra una dirección como `http://192.168.0.10:5173`.
Abrila desde otro celular o compu conectado al mismo Wi-Fi. Los juegos online (salas con código) usan el servidor de tu
compu. Si Windows pregunta por el firewall, dejá pasar a Node en redes privadas.

**Publicarlo en internet (opcional):** los juegos son un sitio estático (`npm run build` → `dist/`) y el servidor online
es `node server/index.js`. Si publicás el servidor (por ejemplo en Render), poné su dirección en `PUBLIC_SERVER`, en
`public/shared/online.js`.

## Qué cambia respecto del original

- Colores lisos en tono tierra en el portal y en los 22 juegos: terracota, petróleo, oliva, mostaza, ciruela y rosa
  viejo sobre fondo gris cálido (también hay tema claro), sin flúor ni brillos. Los colores de los juegos los pasó
  `tools/tierra.mjs`, y los que un juego calcula mientras corre pasan por `tierra()` de `public/shared/tierra.js`.
- Sin anuncios: `src/ads.config.js` queda apagado y sin la cuenta de AdSense del original.
- El online no usa el servidor del original: usa el de tu compu (o el que pongas en `PUBLIC_SERVER`).
- `npm run jugar`, `jugar.bat` y `jugar.sh` levantan los juegos y el servidor de una.

Para traer juegos nuevos del original más adelante:

```bash
git remote add original https://github.com/emitejadaa/game.it   # solo la primera vez
git pull original main
```

Un juego nuevo llega con sus colores originales: `npm run tierra` lo pasa a la paleta tierra (solo toca los juegos que
todavía no pasó; la lista está en `tools/tierra.json`) y avisa qué revisar a mano, como los colores que el juego calcula
mientras corre. Si el original cambió algo de un juego que acá ya está en tierra, git va a pedir elegir cuál dejar.

Los comandos de siempre también andan: `npm run dev` (solo los juegos), `npm run server` (solo el servidor online),
`npm run build` y `npm run check`. Cómo sumar un juego nuevo: [CONTRIBUTING.md](CONTRIBUTING.md).

## Cómo está armado


```
index.html              menú (una sola pantalla) + pantalla de carga
src/
  main.js               arranque, navegación (#play/<id>), atajos de teclado
  core/prefs.js         preferencias globales (localStorage) → CSS y juegos
  core/recent.js        historial local: "Jugados recientemente" y "Para vos"
  core/registry.js      lista de juegos (leída de public/games/*/game.json)
  core/i18n.js          textos ES/EN
  ui/loader.js          pantalla de carga general (menú y juegos)
  ui/search.js          panel de búsqueda que baja desde arriba, con categorías
  ui/prefs-panel.js     popup de preferencias (esquina superior derecha)
  ui/player.js          reproductor: iframe aislado + puente con el SDK
  styles/               tokens (colores, curvas de animación), menú, paneles
public/
  sdk/gameit.js         SDK que usa cada juego
  sw.js                 service worker (caché para cargas instantáneas)
  games/<id>/           cada juego, en cualquier tecnología
```

- **Sin cuentas.** Preferencias e historial se guardan en `localStorage`. Los juegos no guardan progreso.
- **Caché.** En producción un service worker guarda el portal y los juegos ya jugados.
- **Aislamiento.** Cada juego corre en su propio `iframe`: puede ser canvas, WebGL, Phaser, Three.js, Unity, Godot, React… Al salir, el iframe se destruye y se libera memoria, audio y GPU.

## Reglas comunes para todos los juegos

1. **Plataformas.** Cada juego declara en `platforms` si es para computadora, celular o ambos; solo aparece donde se puede jugar. Si es para celular, tiene que funcionar en vertical y horizontal.
2. **Fluidez primero.** 60 fps estables antes que detalle gráfico. Estilo simple y minimalista, bien animado.
3. **Preferencias globales.** El juego respeta tema, color de acento, volumen, "reducir movimiento", brillo neón, teclado (flechas/WASD) e idioma que llegan por el SDK.
4. **Salir.** El portal siempre muestra el botón "Menú". Si el juego tiene su propio menú de pausa, su botón de salir llama a `GameIt.exit()`.
5. **Carga.** El juego llama a `GameIt.ready()` cuando puede mostrarse; mientras tanto se ve la pantalla de carga general.

## Integrar un juego

> **¿Querés sumar un juego al portal?** Seguí [CONTRIBUTING.md](CONTRIBUTING.md) (requisitos, plantilla, fork y pull
> request). Lo que sigue es la referencia técnica.

1. Crear `public/games/<id>/` con el juego ya compilado (su `index.html` y archivos).
2. Agregar `public/games/<id>/game.json`:

```json
{
  "id": "mi-juego",
  "title": "Mi Juego",
  "description": { "es": "Descripción corta.", "en": "Short description." },
  "categories": ["aventura", "historia"],
  "tags": ["pixel", "plataformas"],
  "thumbnail": "thumb.svg",
  "entry": "index.html",
  "tech": "phaser",
  "platforms": ["desktop", "mobile"],
  "sdk": true,
  "orientation": "any",
  "input": ["keyboard", "touch"],
  "features": { "online": false, "multiplayer": false, "story": true },
  "order": 10
}
```

| Campo | Uso |
| --- | --- |
| `id` | Igual al nombre de la carpeta. Define la URL `#play/<id>`. |
| `title`, `description` | Texto o `{ "es": …, "en": … }`. |
| `categories` | `arcade`, `aventura`, `accion`, `puzzle`, `deporte`, `carreras`, `estrategia`, `cartas`, `palabras`, `idle`, `historia`, `online`, `multijugador`, `clasicos`, `casual`. |
| `tags` | Palabras extra para la búsqueda y las recomendaciones. |
| `platforms` | **Obligatorio.** Dónde se puede jugar: `["desktop"]` (computadora/web), `["mobile"]` (celular y tablet) o ambos. El menú, la búsqueda y los recientes muestran solo los juegos jugables en el dispositivo actual. |
| `thumbnail` | Imagen 16:10 (SVG, WebP o PNG). |
| `entry` | Archivo de entrada. También puede ser una URL absoluta (juego alojado en otro servidor). |
| `sdk` | `true` si el juego usa el SDK. Con `false` la carga termina con el evento `load` del iframe. |
| `features` | Capacidades propias del juego (online, multijugador, historia…). Libre para extender. |
| `order` | Orden en el menú (menor = primero). `"hidden": true` lo oculta. |

3. En el `index.html` del juego, sumar el SDK y avisar cuando está listo:

```html
<script src="/sdk/gameit.js"></script>
<script>
  GameIt.onPrefs((p) => {
    // p.theme: 'dark' | 'light'      p.colors: { bg, fg, accent, cyan, magenta, … }
    // p.volume: { master, sfx, music, muted }
    // p.reducedMotion, p.glow, p.showFps, p.keys, p.touch, p.lang
    // p.platform: 'desktop' | 'mobile'
  }, true);
  GameIt.onPause(() => {/* portal abrió preferencias o se ocultó la pestaña */});
  GameIt.onResume(() => {});
  GameIt.progress(0.5); // opcional
  GameIt.ready();
</script>
```

**Anuncios desde el juego** (opcional; si no hay anuncios, todo resuelve enseguida y el juego sigue igual):

```js
GameIt.gameplay(true);   // empieza el juego activo: el portal saca cualquier anuncio
GameIt.gameplay(false);  // menú, pausa o fin de partida: el portal puede mostrar un banner en una franja aparte
await GameIt.commercialBreak('revancha');          // pausa natural antes de seguir (pantalla completa, si está activada)
if (await GameIt.rewardAvailable('continuar')) {   // ofrecer una recompensa solo si hay anuncio disponible…
  if (await GameIt.showReward()) darRecompensa();  // …y darla solo si el jugador lo vio completo
}
```
No llamar a `gameplay(false)` en pantallas donde se toca en cualquier lado (habría clics sin querer en el anuncio).

El SDK además:
- expone los colores como variables CSS (`--gi-bg`, `--gi-fg`, `--gi-accent`, `--gi-cyan`…) y `data-gi-theme` en `<html>`;
- dibuja el contador de FPS si el usuario lo activó;
- traduce teclas con `GameIt.dir(event)` → `'up' | 'down' | 'left' | 'right'` según flechas/WASD;
- elige textos con `GameIt.t({ es, en })`;
- funciona también con el juego abierto suelto (`/games/<id>/`): lee las preferencias guardadas y `exit()` vuelve a `/`.

**Juegos con build propio** (React, Phaser con npm, Unity, Godot): compilar con base relativa (`./`) o con base `/games/<id>/` y copiar la salida a `public/games/<id>/`.
**Juegos online:** el cliente vive acá; el servidor (WebSocket, API) puede estar en otro dominio. Se declara en `features` y el juego maneja su conexión.
El servidor de `server/` tiene un núcleo de salas y un módulo por juego en `server/games/`. Además de `start`/`message`, un módulo
puede declarar `lateJoin` (entrar con la partida en curso), `onJoin`, `removed`, `command` (mensajes en cualquier estado),
`canStart` y `listable` + `listInfo` (lista de salas públicas, mensaje `{ t: 'list', game }`).

### Clashball (tiempo real)

Fútbol 2D con las físicas de HaxBall (`public/games/clashball/shared/`, el mismo código en cliente y servidor):
paso fijo de 60 ticks/s, jugador radio 15 / aceleración 0,1 (0,07 con la patada armada) / amortiguación 0,96,
pelota radio 10 / amortiguación 0,99, patada de fuerza 5 a menos de 4 px, saque con barrera en el círculo, gol de oro.
Online: el servidor simula y manda el estado 30 veces por segundo; cada cliente manda sus teclas solo cuando cambian,
predice su jugador y corrige con las confirmaciones del servidor (se nota como si jugara en local).

### Voleyball (tiempo real)

Vóley de costado como los servidores de vóley de HaxBall, armado sobre Clashball: los jugadores son discos que flotan y se
mueven con la misma física de HaxBall (`shared/physics.js`, 60 ticks/s) y no pueden pasar al otro lado de la red (abajo
la red, arriba una barrera invisible). La pelota cae con gravedad, atraviesa a los jugadores y solo se le pega con la
patada (Espacio/X): sale desde el centro del jugador hacia la pelota, así que desde abajo sube y desde arriba es un
remate. Rebota en las paredes de los costados y en la red; arriba no hay techo (si sale del mapa, una flecha en el borde
la sigue). Reglas en `public/games/voleyball/shared/match.js` (las mismas en el navegador y en el servidor): es punto
cuando la pelota toca el piso, punto por jugada, saca el equipo que hizo el punto (si recupera el saque, rota quién saca),
3 toques por equipo (el saque cuenta como el primero y el bloqueo no cuenta), ganar por 2 opcional y tiempo con punto de
oro. Modos Clásico, Playa (pelota que flota) y Turbo; canchas Chica, Clásica y Grande. Los bots (`shared/ai.js`) simulan
la trayectoria con la misma física, eligen quién va y buscan dónde pararse respecto de la pelota para que el golpe salga
como quieren (recepción alta hacia la red, armado y remate desde arriba, bloqueo en la red y defensa abajo; 3 niveles).
Si un equipo queda vacío (práctica), saca una máquina. Online igual que Clashball (`server/games/voleyball.js`): el
servidor simula, manda el estado 30 veces por segundo con los golpes, piques y puntos como eventos y el cliente predice
su jugador; salas públicas, bots, espectadores y chat con el relato de cada punto (remate, bombazo, ace, bloqueo, punto de
17 toques…).

### Ajedrez

Reglas completas en `public/games/chess/shared/rules.js` (enroque, al paso, coronación, jaque mate, ahogado, material
insuficiente, 50 jugadas y triple repetición; verificado con perft). La compu (`shared/engine.js`, alfa-beta con
tabla de transposición y búsqueda de quietud) corre en un worker (`ai.js`) con 5 niveles. Online, el servidor valida
cada jugada con el mismo archivo y lleva el reloj con incremento; la primera jugada de cada lado tiene 30 s o la
partida se anula. Pista con anuncio opcional (la primera de cada partida es gratis; sin anuncios, todas son gratis).

### Ameba (arena .io)

El mundo (`public/games/ameba/shared/world.js`: comida, división, expulsión de masa, esporas, unión de células)
y los bots (`shared/bots.js`) corren igual en el servidor y sin conexión, a 25 pasos/s con grilla espacial.
Online, cada jugador recibe solo lo que tiene cerca más la comida que reapareció; el cliente interpola los
estados con un retraso que se ajusta al jitter. Juego rápido (se une a la arena pública con más gente o crea una)
o sala privada con código; los bots completan hasta 18. Revivir con anuncio solo sin conexión.

### Serpentina (arena .io)

Mismo esquema que Ameba (`public/games/serpentina/shared/`): el mundo corre igual en el servidor y sin conexión.
El cuerpo de cada serpiente es el rastro de la cabeza muestreado a distancia fija (`grow`), con posiciones y masa
redondeadas a un decimal: `shared/sync.js` manda el cuerpo entero la primera vez que una serpiente entra en vista y
después solo la cabeza, y el cliente reconstruye exactamente el mismo cuerpo. La comida se sincroniza por
casilleros (carga completa al entrar en vista, después solo altas y bajas).

### Billar (bola 8)

Física propia en `public/games/billar/shared/physics.js`: paso fijo de 1/600 s con deslizamiento y rodadura
(efecto arriba, abajo y lateral), choques elásticos, bandas con mandíbulas y troneras. Solo usa + − × ÷ √, así que es
determinista: online el cliente manda el golpe exacto (velocidad y giro iniciales), el servidor lo valida, lo simula
y aplica las reglas (`shared/rules.js`), y los dos navegadores animan el mismo tiro y terminan igual. La mesa se
dibuja con three.js desde arriba y solo se vuelve a renderizar cuando algo cambia. La compu (`shared/ai.js`, en un
worker) prueba tiros simulándolos y juega de seguridad si no hay nada claro.

### Garabato (dibujar y adivinar)

Online de 2 a 10: por turnos uno elige entre tres palabras y la dibuja; los demás escriben en el chat. Acertar da más
puntos cuanto antes (con un plus al primero) y el que dibuja suma una parte de lo que ganan los demás. Con el tiempo se
revelan letras; si una respuesta está a una letra, solo esa persona ve "¡casi!", y los que ya adivinaron charlan entre
ellos sin arruinar la palabra. El servidor (`server/games/garabato.js`) lleva turnos, tiempos y puntos y reenvía el
dibujo como operaciones chicas (trazos, relleno, deshacer, borrar); quien entra tarde o se reconecta recibe el dibujo
en curso. Hoja fija de 1000×750 para que el relleno con balde dé igual en todos los navegadores. Salas públicas
(aparecen en la lista y en "Partida rápida") o privadas, con palabras propias. Listas de palabras propias en
`public/games/garabato/shared/words.js` (español e inglés).

### Teléfono Loco (teléfono descompuesto con dibujos)

Online de 2 a 10: cada uno escribe una frase (o se arranca con frases al azar), las cadenas rotan y al que le llega una
frase la dibuja y al que le llega un dibujo lo describe, sin ver lo anterior; cada cadena pasa una sola vez por cada
jugador (rotación fija, `server/games/telefono.js`). Lo que se escribe y se dibuja llega al servidor mientras se hace,
así nada se pierde si se acaba el tiempo o se corta la conexión; si alguien no responde, el siguiente recibe lo último
útil de la cadena (o una frase al azar). Al final se muestran los álbumes paso a paso para todos a la vez (avanza el
anfitrión o solos), con los dibujos repitiéndose trazo a trazo, reacciones y la opción de guardar cada álbum como una
imagen. Opciones: tiempos de dibujo y de escritura, largo de las cadenas, idioma de las frases y sala pública o
privada. Frases en `public/games/telefono/shared/prompts.js`; la hoja y el balde en `paper.js`.

### La Cabra · Pádel

Adaptación del partido de [LA CABRA · Pádel](https://github.com/LucasPar08/la-cabra-padel) de LucasPar08: solo el partido
(sin carrera ni modo historia), con los tres escenarios (pabellón, exterior y club), la cámara de tele o desde arriba y
las opciones de dificultad, estilo de los rivales, juegos por set (3, 4 o 6), 1 set o al mejor de 3, lado (revés o
drive), asistencia, golpe automático, mano, tamaño de los botones y colores. El motor (`public/games/padel/shared/engine.js`:
paso fijo de 1/120 s, cristal y malla, salidas por 3 y por 4, punto de oro, tie-break, la IA de pareja y rivales) es el
mismo en el navegador y en el servidor. Contra la compu, vos y tu pareja contra dos rivales. Online de 2 a 4
(`server/games/padel.js`): se arman los equipos en la sala, los lugares vacíos los juega la compu, el servidor simula a
60 ticks/s y manda el estado 30 veces por segundo con los golpes y botes como eventos; el cliente dibuja con 70 ms de
retraso e interpola. Si alguien se va o se corta, un bot sigue en su lugar hasta que vuelve. Nombres de jugadores y
equipos inventados.

### Batalla Naval

Contra la compu u online 1 contra 1. Reglas en `public/games/naval/shared/rules.js` (las mismas en el navegador y en
el servidor): mares de 8×8, 10×10 o 12×12 con flotas de 4, 5 o 7 barcos, barcos que se tocan o no (si no, al hundir
uno se marca el agua de alrededor), tiro extra al acertar, modo salva (tantos disparos como barcos a flote) y armas
especiales de un solo uso: sonar (muestra los barcos de un 3×3), bomba (5 casillas en cruz) y torpedo (recorre una
fila o columna y explota en el primer barco). La compu (`shared/ia.js`) tiene tres niveles: al azar con algo de
seguimiento, caza en damero siguiendo la línea de los tocados, y mapa de probabilidad de todas las posiciones
posibles de los barcos que quedan, usando las armas cuando convienen. Online (`server/games/naval.js`) la flota de
cada uno nunca sale del servidor hasta el final; cada turno tiene tiempo (20, 30 o 60 s; si se acaba, tiro al azar),
se alterna quién empieza y se puede reaccionar con emojis. Todo se dibuja en canvas (barcos vistos desde arriba,
fuego, humo, piques, sonar y torpedos) y en celulares vertical el mar que recibe el disparo se agranda.

### Mecha Corta (palabras)

Juego de palabras con bomba: el que la tiene ve una sílaba y escribe una palabra que la contenga (existente y sin
repetir) antes de que explote; la mecha dura un tiempo al azar que nadie ve y explotar cuesta una vida. Usar todas las
letras del abecedario (menos las raras) da una vida extra y todos ven lo que escribe el de turno, letra por letra.
Idiomas español e inglés con diccionarios de `an-array-of-spanish-words` y `an-array-of-english-words` (MIT, ver
`public/games/mecha/dict/LICENSE.txt`), guardados ordenados y con codificación de prefijo (≈2,4 MB y 1,2 MB sin
comprimir) y buscados con búsqueda binaria; se regeneran con `node tools/mecha-dict.mjs`. La partida
(`shared/game.js`) corre igual en el navegador (compu o práctica) y en el servidor (online hasta 12, con compu opcional),
que valida las palabras y no revela cuánto le queda a la mecha.

### Chispa (cartas)

Juego de cartas de colores con nombre, diseño y cartas propias (4 colores de neón con una forma cada uno para quien no
distingue colores). Las reglas están en `public/games/chispa/shared/rules.js` y la mesa (rondas, puntos, turnos de la
compu, tiempo por turno y lo que ve cada jugador) en `shared/table.js`: el mismo código corre en el navegador contra la
compu y en el servidor online, que baraja, valida cada jugada y a cada jugador le manda solo su mano. Se avisa
"¡Última!" con una carta; si otro te agarra antes de que juegue el siguiente, robás 2. Opcional: acumular +2/+4.
Online de 2 a 6 (el anfitrión puede sumar compu); si alguien se desconecta juega solo hasta que vuelve.

### Drift Neon

Física arcade propia en `public/games/drift/shared/car.js` (paso fijo de 1/120 s): el volante define una velocidad de
giro que el auto alcanza con inercia y el agarre gira la velocidad hacia la trompa sin crear energía. Para derrapar se
tira del freno de mano doblando (o se frena/acelera fuerte en plena curva); el acelerador sostiene el derrape, el
contravolante lo cierra y pasado cierto ángulo es trompo. Quince pistas largas (`tracks.js`, de 1,5 a 2,1 km
cada una) con tema propio (ciudad, autopista, desierto, puerto, costa, montaña, nieve, estadio, aeródromo, cañón,
bosque con río, volcán, base lunar y bahía con lluvia): unas con puntos de control y otras trazadas con rectas y
curvas de radio exacto (`shared/turtle.js`, que cierra el circuito solo), todas validadas para que ningún tramo se
pise con otro. Todas tienen grava en las curvas cerradas, flechas y carteles de frenada. La compu (`shared/ai.js`) usa la misma física: sigue una línea de carrera
calculada, frena antes de las curvas, usa freno de mano en las horquillas y nitro en las rectas (tres niveles).
Modos: carrera contra hasta 5 autos de la compu, contrarreloj contra el fantasma de tu mejor recorrido de la sesión
(con parciales), desafío de drift, 2 jugadores en pantalla dividida y online de hasta 6 (el servidor valida los
tiempos con el largo de cada pista). El selector muestra el mapa grande con sus datos (largo, curvas, recta más
larga, dificultad, superficie y récord). El fondo se dibuja en mosaicos cacheados, así solo se redibuja lo que se
mueve.

El registro se genera solo: al agregar la carpeta con `game.json`, el juego aparece en el menú, la búsqueda y las categorías.
