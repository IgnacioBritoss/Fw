#!/bin/sh
# Para jugar en Mac o Linux: ./jugar.sh
cd "$(dirname "$0")" && exec node tools/jugar.mjs
