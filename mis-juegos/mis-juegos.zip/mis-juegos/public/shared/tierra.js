/**
 * Paleta tierra: convierte cualquier color a su versión lisa y apagada (sin flúor). La usan la
 * herramienta que pasó los juegos a esta paleta (tools/tierra.mjs) y los juegos que calculan colores
 * mientras corren:
 *
 *   import { tierra } from '/shared/tierra.js';
 *   ctx.fillStyle = tierra(`hsl(${tono}, 70%, 55%)`);
 *
 * Acepta #hex, rgb(), rgba(), hsl(), hsla() y nombres de color; si no entiende el color, lo devuelve
 * igual. Guarda los últimos resultados, así llamarla en cada cuadro no cuesta.
 */

// ---------------------------------------------------------------- color: sRGB <-> OKLab <-> OKLCH

const toLin = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4);
const toGam = (c) => (c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055);

export function rgbToOklch([r, g, b]) {
  const R = toLin(r / 255), G = toLin(g / 255), B = toLin(b / 255);
  const l = Math.cbrt(0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B);
  const m = Math.cbrt(0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B);
  const s = Math.cbrt(0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B);
  const L = 0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s;
  const a = 1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s;
  const bb = 0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s;
  const C = Math.hypot(a, bb);
  let h = (Math.atan2(bb, a) * 180) / Math.PI;
  if (h < 0) h += 360;
  return { L, C, h };
}

function oklchToLinear({ L, C, h }) {
  const a = C * Math.cos((h * Math.PI) / 180);
  const b = C * Math.sin((h * Math.PI) / 180);
  const l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3;
  const m = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3;
  const s = (L - 0.0894841775 * a - 1.291485548 * b) ** 3;
  return [
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
  ];
}

const inGamut = (lin) => lin.every((c) => c >= -1e-4 && c <= 1 + 1e-4);

/** OKLCH → [r, g, b] 0-255; si el color no entra en sRGB, baja la saturación hasta que entre. */
function oklchToRgb(c) {
  let lin = oklchToLinear(c);
  if (!inGamut(lin)) {
    let lo = 0, hi = c.C;
    for (let i = 0; i < 24; i++) {
      const mid = (lo + hi) / 2;
      if (inGamut(oklchToLinear({ ...c, C: mid }))) lo = mid;
      else hi = mid;
    }
    lin = oklchToLinear({ ...c, C: lo });
  }
  return lin.map((v) => Math.round(Math.min(1, Math.max(0, toGam(Math.min(1, Math.max(0, v))))) * 255));
}

// ---------------------------------------------------------------- la paleta

/** Tonos hacia los que se llevan los colores y cuánta saturación admite cada uno (croma OKLCH). */
const ANCLAS = [
  { h: 3, c: 0.11 }, // rosa viejo
  { h: 33, c: 0.14 }, // terracota
  { h: 84, c: 0.135, margen: 8 }, // mostaza (el amarillo puro, tono 110, cae acá y no en oliva)
  { h: 135, c: 0.11 }, // oliva
  { h: 190, c: 0.075 }, // verde azulado
  { h: 244, c: 0.09 }, // petróleo
  { h: 313, c: 0.1 }, // ciruela
];

const dif = (a, b) => ((a - b + 540) % 360) - 180; // a - b, en (-180, 180]
const lerp = (a, b, t) => a + (b - a) * t;
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const smooth = (a, b, v) => {
  const t = clamp((v - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

/** Tope de saturación para un tono: interpolado entre las dos anclas que lo rodean. */
function tope(h) {
  for (let i = 0; i < ANCLAS.length; i++) {
    const a = ANCLAS[i], b = ANCLAS[(i + 1) % ANCLAS.length];
    const span = (b.h - a.h + 360) % 360;
    const off = (h - a.h + 360) % 360;
    if (off <= span) return lerp(a.c, b.c, off / span);
  }
  return 0.1;
}

function anclaCercana(h) {
  let best = ANCLAS[0];
  const d = (a) => Math.abs(dif(h, a.h)) - (a.margen || 0);
  for (const a of ANCLAS) if (d(a) < d(best)) best = a;
  return best;
}

/** El corazón: un color OKLCH → su versión tierra. */
export function tierraLch({ L, C, h }) {
  // Luz: los negros puros suben a gris cálido oscuro (el fondo del portal) y el blanco puro baja a crema.
  const L1 = 0.1435 + 0.8115 * L; // #07070a (el fondo del original) → #23211f (el del portal)

  // Gris cálido (para los grises y casi grises, que en los juegos flúor suelen ser azulados).
  const neutro = { L: L1, C: 0.004 + 0.009 * L1, h: 70 };

  // Color: tono hacia la paleta, saturación con tope suave y menos luz si era chillón.
  const ancla = anclaCercana(h);
  const h1 = (h + dif(ancla.h, h) * 0.5 + 360) % 360;
  const top = tope(h1);
  const k = 0.6 * top;
  let C1 = C <= k ? C : k + (top - k) * Math.tanh((C - k) / (top - k));
  const chillon = clamp((C - 0.06) / 0.1, 0, 1);
  const L2 = L1 - 0.55 * Math.max(0, L1 - 0.62) * chillon;
  if (L2 < 0.45) C1 *= 0.55 + 0.45 * (L2 / 0.45); // los oscuros, todavía más apagados
  const color = { L: L2, C: C1, h: h1 };

  // Transición pareja entre gris y color (mezcla en OKLab).
  const t = smooth(0.02, 0.06, C);
  const ax = lerp(neutro.C * Math.cos((neutro.h * Math.PI) / 180), color.C * Math.cos((color.h * Math.PI) / 180), t);
  const bx = lerp(neutro.C * Math.sin((neutro.h * Math.PI) / 180), color.C * Math.sin((color.h * Math.PI) / 180), t);
  let hh = (Math.atan2(bx, ax) * 180) / Math.PI;
  if (hh < 0) hh += 360;
  return { L: lerp(neutro.L, color.L, t), C: Math.hypot(ax, bx), h: hh };
}

export const tierraRgb = (rgb) => oklchToRgb(tierraLch(rgbToOklch(rgb)));

// ---------------------------------------------------------------- leer y escribir colores

export const NOMBRES = {
  black: '#000000', white: '#ffffff', red: '#ff0000', green: '#008000', blue: '#0000ff', yellow: '#ffff00',
  orange: '#ffa500', purple: '#800080', pink: '#ffc0cb', gray: '#808080', grey: '#808080', cyan: '#00ffff',
  magenta: '#ff00ff', lime: '#00ff00', gold: '#ffd700', silver: '#c0c0c0', navy: '#000080', teal: '#008080',
  maroon: '#800000', olive: '#808000', aqua: '#00ffff', fuchsia: '#ff00ff', violet: '#ee82ee', indigo: '#4b0082',
  crimson: '#dc143c', coral: '#ff7f50', tomato: '#ff6347', salmon: '#fa8072', orchid: '#da70d6', hotpink: '#ff69b4',
  deeppink: '#ff1493', skyblue: '#87ceeb', royalblue: '#4169e1', dodgerblue: '#1e90ff', deepskyblue: '#00bfff',
  limegreen: '#32cd32', lawngreen: '#7cfc00', chartreuse: '#7fff00', springgreen: '#00ff7f', turquoise: '#40e0d0',
  khaki: '#f0e68c', beige: '#f5f5dc', ivory: '#fffff0', whitesmoke: '#f5f5f5', gainsboro: '#dcdcdc',
  lightgray: '#d3d3d3', lightgrey: '#d3d3d3', darkgray: '#a9a9a9', darkgrey: '#a9a9a9', dimgray: '#696969',
  dimgrey: '#696969', slategray: '#708090', brown: '#a52a2a', tan: '#d2b48c', chocolate: '#d2691e',
  firebrick: '#b22222', darkred: '#8b0000', darkgreen: '#006400', darkblue: '#00008b', midnightblue: '#191970',
  orangered: '#ff4500', goldenrod: '#daa520', greenyellow: '#adff2f', yellowgreen: '#9acd32', plum: '#dda0dd',
  lavender: '#e6e6fa', mintcream: '#f5fffa', snow: '#fffafa', linen: '#faf0e6', wheat: '#f5deb3',
};

const hex2 = (n) => n.toString(16).padStart(2, '0');
export const toHex = ([r, g, b]) => `#${hex2(r)}${hex2(g)}${hex2(b)}`;

export function parseHex(h) {
  h = h.replace('#', '');
  if (h.length === 3 || h.length === 4) h = [...h].map((c) => c + c).join('');
  const rgb = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
  const alpha = h.length === 8 ? h.slice(6, 8) : null;
  return { rgb, alpha };
}

function hslToRgb(h, s, l) {
  s /= 100;
  l /= 100;
  const k = (n) => (n + h / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const f = (n) => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
  return [f(0), f(8), f(4)].map((v) => Math.round(v * 255));
}

/** Convierte un color escrito en un string; devuelve el mismo formato (hsl pasa a hex o rgba). */
export function mapToken(tok) {
  const t = tok.trim();
  let m;
  if ((m = /^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/i.exec(t))) {
    const { rgb, alpha } = parseHex(t);
    const out = toHex(tierraRgb(rgb));
    if (alpha) return out + alpha;
    if (m[1].length === 4) return out + m[1][3] + m[1][3];
    return out;
  }
  if ((m = /^0x([0-9a-f]{6})$/i.exec(t))) return '0x' + toHex(tierraRgb(parseHex(m[1]).rgb)).slice(1);
  if ((m = /^(rgba?)\(\s*([\d.]+%?)\s*[, ]\s*([\d.]+%?)\s*[, ]\s*([\d.]+%?)\s*(?:[,/]\s*([\d.]+%?)\s*)?\)$/i.exec(t))) {
    const ch = [m[2], m[3], m[4]].map((v) => (v.endsWith('%') ? (parseFloat(v) * 255) / 100 : parseFloat(v)));
    const [r, g, b] = tierraRgb(ch.map((v) => Math.round(clamp(v, 0, 255))));
    return m[5] !== undefined ? `rgba(${r}, ${g}, ${b}, ${m[5]})` : `rgb(${r}, ${g}, ${b})`;
  }
  if ((m = /^(hsla?)\(\s*([\d.]+)(?:deg)?\s*[, ]\s*([\d.]+)%\s*[, ]\s*([\d.]+)%\s*(?:[,/]\s*([\d.]+%?)\s*)?\)$/i.exec(t))) {
    const rgb = tierraRgb(hslToRgb(parseFloat(m[2]), parseFloat(m[3]), parseFloat(m[4])));
    return m[5] !== undefined ? `rgba(${rgb.join(', ')}, ${m[5]})` : toHex(rgb);
  }
  const low = t.toLowerCase();
  if (NOMBRES[low]) return toHex(tierraRgb(parseHex(NOMBRES[low]).rgb));
  return null;
}

const memo = new Map();

/** Un color escrito (como en CSS) → su versión tierra, en el formato más parecido. */
export function tierra(color) {
  let out = memo.get(color);
  if (out === undefined) {
    out = mapToken(String(color)) || color;
    if (memo.size > 4000) memo.clear();
    memo.set(color, out);
  }
  return out;
}
