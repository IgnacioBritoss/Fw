@echo off
rem Doble clic para jugar: levanta los juegos y el servidor online y abre el navegador.
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Falta Node.js. Instalalo desde https://nodejs.org ^(version 20 o mas nueva^) y volve a abrir este archivo.
  pause
  exit /b 1
)
node tools\jugar.mjs
pause
